(function ($) {
    "use strict";

    /*---------------------------
       Commons Variables
    ------------------------------ */
    var $window = $(window),
        $body = $("body");

   /* window.addEventListener("resize", function() {
		"use strict"; window.location.reload();
    });*/

    /*-----  Hover Dropdown Navigation Start -----*/
    if (window.innerWidth > 992) {
        document.querySelectorAll('.navbar .nav-item').forEach(function (everyitem) {
            everyitem.addEventListener('mouseover', function (e) {
                let el_link = this.querySelector('a[data-bs-toggle]');
                if (el_link != null) {
                    let nextEl = el_link.nextElementSibling;
                    el_link.classList.add('show');
                    nextEl.classList.add('show');
                    nextEl.setAttribute("data-bs-popper", "static");
                }
            });
            everyitem.addEventListener('mouseleave', function (e) {
                let el_link = this.querySelector('a[data-bs-toggle]');
                if (el_link != null) {
                    let nextEl = el_link.nextElementSibling;
                    el_link.classList.remove('show');
                    nextEl.classList.remove('show');
                    nextEl.removeAttribute("data-bs-popper");
                }
            })
        });
    }
    /*-----  Hover Dropdown Navigation End  -----*/

    /*-----  enable Tooltip start -----*/
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
    /*-----  enable Tooltip end -----*/

    /*-----  Tab List Mobile -----*/
    if (window.innerWidth < 992) {
        $('.nav_tabs.nav_tabs_steps .nav-item .nav-link').not('.active').hide();
        $('.nav_tabs.nav_tabs_steps .nav-item .nav-link').click(function(){
            $('.nav_tabs.nav_tabs_steps .nav-item .nav-link').toggle();
            $('.nav_tabs.nav_tabs_steps .nav-item .nav-link.active').show();
        });
    }
    /*-----  Tab List Mobile -----*/

    /*-----  Help Text Model -----*/
    const helpModal = document.getElementById('helpModal');
    if(typeof(helpModal) != 'undefined' && helpModal != null){
        helpModal.addEventListener('show.bs.modal', event => {
            const button = event.relatedTarget;
            const helpText = button.getAttribute('data-bs-helpText');
            const helpTitle = button.getAttribute('data-bs-helpTitle');
            const modalTitle = helpModal.querySelector('.modal-title');
            const modalBody = helpModal.querySelector('.modal-body');

            modalTitle.innerHTML = helpTitle;
            modalBody.innerHTML = helpText;
        })
    }
    /*-----  Help Text Model -----*/

    /*-----  Continue/Done Button -----*/
    $('.btn_continue').click(function(){
        $('.nav_tabs_steps.nav_tabs .nav-link.active').parents('.nav-item').next('.nav-item').find('button').trigger('click');
        if (window.innerWidth < 992) {
            $('.nav_tabs.nav_tabs_steps .nav-item .nav-link').not('.active').hide();
        }
    });

    const lastTab = document.querySelector('.nav_tabs_steps.nav_tabs .nav-item:last-child button[data-bs-toggle="tab"]');
   
    if(typeof(lastTab) != 'undefined' && lastTab != null){
        lastTab.addEventListener('shown.bs.tab', event => {
            //$('.btn_continue').addClass('justify-content-center').html('DONE');
            //$('.btn_continue').attr('id','test');
            // $('.btn_continue').prop("type", "submit");
			$('.btn_continue').hide();
			$('.btn_done').show();
            $('.terms-p').show();
        })
        lastTab.addEventListener('hidden.bs.tab', event => {
            //$('.btn_continue').removeClass('justify-content-center').html('Continue <i class="fa fa-angle-right" aria-hidden="true"></i>');
            //$('.btn_continue').prop("type", "button");
            //$('.btn_continue').attr('id','my-button');
			$('.btn_continue').show();
			$('.btn_done').hide();
            $('.terms-p').hide();
        })
    }


    /*----- Continue/Done Button -----*/

    /*----- Country button Button -----*/
    $('.verifiable_address_field').each(function() {
        if($(this).children("option:selected").val() == 'US'){
            $(this).parents('.group_address').find('.usa-data').show();
            $(this).parents('.group_address').find('.non-usa-data').hide();
        }
    });
    $('.verifiable_address_field').change(function(){
        if($(this).val() == 'US'){
            $(this).parents('.group_address').find('.usa-data').show();
            $(this).parents('.group_address').find('.non-usa-data').hide();
        }else{
            $(this).parents('.group_address').find('.usa-data').hide();
            $(this).parents('.group_address').find('.non-usa-data').show();
        }
    });
    /*----- Country button Button -----*/

    /*----- Specify Address Select  Start -----*/
    $('body').on('change','.person-address-select',function(){
        var value = $(this).val();
        if($(this).val() == 'Specify Address'){
            $(this).parent().parent().find('textarea').show();
        }else{
            $(this).parent().parent().find('textarea').hide();
        }
    });
    /*----- Specify Address Select  End -----*/
 $("body").on("click",".btn_done",function () {
            alert("OK");
        });

}(jQuery));
