@extends('admin.layouts.master')
@section('title',$title)
@section('content')
	<!--begin::Entry-->
	<div class="d-flex flex-column-fluid">
		<!--begin::Container-->
		
		<!--end::Container-->
	</div>
	<!--end::Entry-->
@endsection
